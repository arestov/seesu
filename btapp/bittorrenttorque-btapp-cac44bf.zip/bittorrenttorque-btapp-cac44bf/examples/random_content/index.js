jQuery(function() {
	var content = new BtappContent;
});